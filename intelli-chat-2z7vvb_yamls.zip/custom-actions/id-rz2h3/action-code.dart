Future deleteHistory(String userId) async {
  CollectionReference collection = await FirebaseFirestore.instance
      .collection("history")
      .doc(userId)
      .collection("historyItems");
  var snapshots = await collection.get();
  for (var doc in snapshots.docs) {
    await doc.reference.delete();
  }
}