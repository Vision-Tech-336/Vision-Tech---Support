import 'package:scroll_loop_auto_scroll/scroll_loop_auto_scroll.dart';

class QuestionaryView extends StatefulWidget {
  const QuestionaryView({
    super.key,
    this.width,
    this.height,
  });

  final double? width;
  final double? height;

  @override
  State<QuestionaryView> createState() => _QuestionaryViewState();
}

class _QuestionaryViewState extends State<QuestionaryView> {
  @override
  Widget build(BuildContext context) {
    return ScrollLoopAutoScroll(
      scrollDirection: Axis.horizontal,
      child: Column(
        children: [],
      ),
    );
  }
}