import 'package:url_launcher/url_launcher_string.dart';
import 'package:flutter_markdown/flutter_markdown.dart';

class AnswerView extends StatefulWidget {
  const AnswerView({
    super.key,
    this.width,
    this.height = double.infinity,
    required this.text,
  });

  final double? width;
  final double? height;
  final String text;

  @override
  State<AnswerView> createState() => _AnswerViewState();
}

class _AnswerViewState extends State<AnswerView> {
  @override
  Widget build(BuildContext context) {
    return Markdown(
      data: widget.text,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      selectable: true,
      onTapLink: (text, href, title) => launchUrlString(text),
      padding: EdgeInsets.zero,
    );
  }
}