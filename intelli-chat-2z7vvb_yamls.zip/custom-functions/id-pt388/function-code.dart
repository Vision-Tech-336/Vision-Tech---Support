
  double designHeight = 852;

  return ((px * screenHeight) / designHeight).floorToDouble();