
  if (chatList != null && chatList.isNotEmpty && chatList.length >= setIndex) {
    return chatList.length - setIndex;
  } else {
    return 0;
  }