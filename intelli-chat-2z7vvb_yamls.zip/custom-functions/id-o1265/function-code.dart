
  return value != null && value.bytes != null && value.bytes!.isNotEmpty;