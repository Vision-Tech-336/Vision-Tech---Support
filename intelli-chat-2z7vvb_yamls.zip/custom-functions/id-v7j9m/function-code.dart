
  return value != null && value.isNotEmpty;