
  double designWidth = 390;

  double value = ((px * screenWidth) / designWidth).floorToDouble();

  return value;